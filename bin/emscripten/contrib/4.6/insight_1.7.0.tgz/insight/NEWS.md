# insight 1.7.0

## Changes

* `get_predicted()` with `ci_method = "satterthwaite"` or
  `ci_method = "kenward-roger"` is faster for `lmerMod` models. The steps that
  are the same for every row of the data are now computed once. The results
  do not change.

## Bug fixes

* Tweak test tolerance to fix CRAN check errors.

* Fixed issue, where `get_df(type = "model")` and `n_parameters()` did not
  include absorbed parameters for models of class `lm_robust`.

# insight 1.6.1

## New supported models

* Support for models of class `nlme` from `nlme::nlme()`. `find_formula()`
  returns the same parts as for `lme4::nlmer()` models: `conditional`,
  `nonlinear` and `random`. `conditional` has the response and the covariates
  of the fixed-effect parameter formulas. `nonlinear` has the nonlinear model,
  and `random` has the random part. As for `nlme::lme()` models,
  `find_formula()` also returns a `correlation` part. Functions that use the
  formula, like `find_variables()`, `get_response()`, `get_random()` and
  `get_predicted()`, now work for these models. `get_predicted()` returns standard errors and
  confidence intervals for predictions, computed with the delta method from
  the Jacobian of `predict()` with respect to the fixed effects. Prediction
  intervals are not yet supported. `get_variance()` returns `NULL` with a
  message, because the random effects are on the scale of the nonlinear
  parameters.

## Changes

* `find_predictors()`, `find_variables()`, `find_terms()` and `clean_names()`
  no longer return the nonlinear parameters as variables for models from
  `stats::nls()`, `lme4::nlmer()` and `nlme::nlme()`. For the nonlinear
  formula, `find_terms()` now returns the same as `find_variables()`, so
  transformations like `log(conc)` are no longer returned there.
  `find_parameters()` for `nls` models now returns the coefficients, not the
  variables (#350).

* `find_predictors()` and `find_variables()` no longer return the grouping
  factor of a correlation structure, like `Subject` in
  `corAR1(form = ~ age | Subject)`, as fixed predictor for models from *nlme*
  and `MASS::glmmPQL()`. It is still returned for `effects = "all"`.
  `get_datagrid()` no longer includes variables that are only used in the
  correlation structure, unless requested in `by`.

* `find_formula()` for models from `nlme::lme()`, `nlme::gls()`,
  `nlme::nlme()` and `MASS::glmmPQL()` now reads the `correlation` part from
  the fitted correlation structure, not from the model call. Before, a
  structure object that was created inside a function gave an error or no
  `correlation` part. A `form` that was not a named argument gave no
  `correlation` part. A global structure object that was changed after the fit
  gave the changed formula. A structure without `form` now returns the
  grouping that the model used, like `~1 | Subject`. `find_variables()` and
  `find_predictors()` with `effects = "all"` then also return that grouping
  factor as a `correlation` variable.
  If that formula has no variable, like `~1` for `gls()` models, there is no
  `correlation` part.

* `get_parameters()` for *lavaan* models, and for *blavaan* models with
  `summary = TRUE`, now returns standardized parameters only for
  `standardize = TRUE`, as it does for the posterior draws of *blavaan* models.
  Before, values such as `1` or `"TRUE"` also returned standardized
  parameters, and values such as `"yes"`, `NA` or `NULL` gave an error.

* `get_modelmatrix()` now works for models from `stats::arima()` (#1274). It
  returns the columns of the `xreg` regressors, named like the coefficients.
  For a model with an intercept, the first column is the intercept.
  `stats::arima()` does not store `xreg`, so it is evaluated from the model
  call. The objects in `xreg` must be visible from where `get_modelmatrix()` is
  called, or from the global environment, and must be unchanged. Models from
  `forecast::Arima()` use their stored regressors. A `data` argument gives an
  error, because new data is not supported.

## Bug fixes

* `get_data()` for multivariate models from package _brms_ now also returns
  the predictors of distributional parameters, such as `sigma ~ z`, when the
  data are taken from the model frame. This is the case for models fitted with
  `brm_multiple()`. Before, these columns were missing.

* `get_predicted()` now passes arguments in `...` to `predict()` for models
  that use the default method, like *betareg*. Before, these arguments were
  ignored, e.g. `at` for `type = "quantile"`. If `predict()` fails with these
  arguments, or they change the shape of the predictions (like `se.fit`),
  predictions are computed without them.

* `is_converged()` for `coxph` models now returns `FALSE` with a message that
  convergence cannot be assessed in two more cases. In the first case, the
  call does not write the formula as a `~` expression, such as
  `coxph(f, ...)`. A control argument of this call uses a variable. Before,
  `is_converged()` evaluated these arguments in the environment of the
  formula. For a model fitted inside a function, an object with the same name
  in that environment gave other control values than the fit used.
  Models of this kind that were assessed correctly before, for example in
  top-level code, now also return `FALSE`. The second case is a right-censored
  single-state model with a `strata()` term whose strata variable now puts
  observations in other strata. Before, `is_converged()` flagged coefficients
  as infinite by mistake. The second case does not apply to models fitted with
  `model = TRUE` or `x = TRUE`.

* `get_sigma()` for models from package _VGAM_ now returns the standard
  deviation parameter of families that have one, such as `uninormal()`,
  `tobit()` or `binormal()`. Before, it returned a wrong value. A model with
  more than one standard deviation parameter returns one value for each. If
  the standard deviation is modeled with predictors, `get_sigma()` returns
  `NULL`.

* `get_loglikelihood()` for `mgcv::gamm()` and `gamm4::gamm4()` models now
  returns the log-likelihood of the mixed model part (`$lme` or `$mer`), which
  includes the random effects. Before, it used only the `$gam` part. For
  `gamm()` models fitted by PQL, it now returns `NA` with a warning, because
  the log-likelihood of the PQL working model is not the one of the GAMM.

* `get_loglikelihood()` for `nlme::lme()` and `nlme::gls()` models fitted by
  REML now returns the ML log-likelihood with `estimator = "ML"`. Before,
  `estimator` was ignored.

* `is_converged()` for `coxph` models now returns `FALSE` with a message that
  convergence cannot be assessed in three more cases. The first case is a
  model without events. Before, a right-censored model without events gave
  `TRUE`. The second case is a right-censored model whose predictor data
  changed after the fit. Before, the result depended on the change: `TRUE`,
  coefficients flagged as infinite, or a message that the score vector was
  not computed. Models fitted with `model = TRUE` are not affected. The third
  case is a model object with a missing number of iterations or missing
  variances. Before, these gave an error or `TRUE`. A model without events
  and without predictors now returns `TRUE`, as other null models. Before, it
  returned `FALSE`. With `verbose = FALSE`, `is_converged()` now also gives
  no message for models that it does not support.

* `is_converged()` for `coxph` models now assesses models from
  `survival::clogit()` fitted with `method = "efron"` or `method = "breslow"`.
  Before, it returned `NULL`. Models from `clogit()` with predictors and the
  default `method = "exact"` now return `FALSE` with a message that
  convergence cannot be assessed. Single-state counting-process models fitted with `y = FALSE`
  are now assessed. The check for changed predictor data now also runs for
  multi-state models with right-censored data. If transitions share a
  baseline hazard or the model was fitted with `x = TRUE`, it does not run.
  It also runs for models with factor predictors or a
  `strata()` term, which skipped it before. A change to the `strata()`
  variable of a multi-state model is still not detected. If the predictor
  data of these models changed after the fit, they now return `FALSE` with a
  message that convergence cannot be assessed. Before, the result depended on
  the change, and coefficients were flagged as infinite by mistake. A model
  object with zero iterations now also returns `FALSE` with this message. If
  the data of the model can be read, the message no longer suggests to refit
  the model with `model = TRUE`.

* `link_inverse()` and `link_function()` now work for brms custom families with
  brms-only links like `softplus` or `squareplus`.

* `export_table(format = "html")` now applies `align` to the columns that the
  table shows, in the order shown. `align = "left"`, `"right"` or `"center"`
  aligns all columns. Before, `export_table()` read these words as one
  character per column, and it gave an error for tables with fewer columns
  than letters. A string with one character per column skips the characters
  of the group columns (like `Component` or the `by` columns). Before, this
  worked only without `rowname_col`, and a group column with one value gave
  an error. A string with fewer characters now applies to the shown
  columns only. Columns that `column_groups` moves under a spanner take the
  character of their shown position. Extra characters are ignored.

* If one group column has one value, or a `by` column is not in the data,
  `export_table(format = "html")` now makes row groups from the other group
  columns with two or more values. Before, it made no row groups in these
  cases. With `row_groups`, it still makes no row groups in these cases.

* `export_table(format = "html")` for a list of data frames with an `Effects`
  column now labels the row groups with the table captions only, like
  `"Fixed Effects"`. Before, the labels repeated the `Effects` value, like
  `"fixed - Fixed Effects"`. If the `Effects` column has one value for each
  caption, `export_table()` removes it. Otherwise, it is kept. For lists with
  an `Effects` or `Component` column, the first caption is no longer also used
  as the table title.

* `get_variance()` no longer returns `NULL` for models from `MASS::glmmPQL()`.
  `get_modelmatrix()` failed for these models with the error
  `object 'zz' not found`, because the model terms have the working response
  of the fitting algorithm.

* `null_model()` now works for models from `nlme::lme()` and
  `MASS::glmmPQL()`. Before, it failed, so `get_variance()` returned a
  distribution-specific variance of 0 for `glmmPQL` models of families such as
  Poisson.

# insight 1.6.0

## New supported models

* Support for models of class `glmmTMB` fitted with the new `ordinal()`
  family (*glmmTMB* >= 1.1.15). As for `ordinal::clm()`, the thresholds are
  returned as conditional parameters ahead of the slopes, with standard errors
  and statistics obtained via the delta method (the thresholds are estimated on
  an internal, softmax-parameterized scale), while the intercept, which is
  fixed to zero by *glmmTMB*, is dropped. `get_predicted()` returns
  per-category probabilities for `predict = "expectation"` and the most likely
  category for `predict = "classification"`, and `get_variance()` uses the
  distribution-specific residual variance of the latent scale, as for
  `ordinal::clmm()`.

## Changes

* `is_converged()` now supports `CmdStanMCMC` models from *cmdstanr*, with the
  same checks and thresholds as for other Stan models. The values come from
  the `$diagnostic_summary()` and `$summary()` methods of the model. Other
  *cmdstanr* models, for example from `$variational()` or `$optimize()`,
  return `FALSE` with a message. `stanfit` models from `rstan::read_stan_csv()`
  store the maximum treedepth outside `control`. For these models,
  `is_converged()` counts treedepth hits against this stored maximum, not
  against the default of 10.

* `get_parameters()` for *lavaan* and *blavaan* models gets a `type` argument
  (in `...`). If `standardize = TRUE` and `type` is given, it is passed to
  `lavaan::standardizedSolution()` or `blavaan::standardizedPosterior()`, for
  example `type = "std.lv"` or `type = "std.nox"`. The default is still
  `"std.all"`.

* `get_variance()` for `nlme::lme()` models now returns `cor.slopes`, the
  correlations between random slopes, as for *lme4* models. Before, it was
  missing. This works for nested and non-nested grouping factors with general
  covariance blocks (`pdSymm` and the default `pdLogChol`). Blocks of class
  `pdDiag` or `pdIdent` do not estimate correlations, so they add no entry to
  `cor.slopes`.

* `export_table(format = "html")` passes arguments of `gt::gt()` from `...`
  to `gt::gt()`, for example `id` or `rowname_col` (#631).

* `is_converged()` now supports models fitted with Stan (`stanfit`, `brmsfit`
  and `stanreg`). Before, it did not work for these models.
  It checks divergent transitions, transitions at the maximum treedepth,
  E-BFMI, R-hat, and bulk and tail effective sample size, with the thresholds
  of the warnings that *rstan* gives after sampling.
  E-BFMI is computed as in `rstan::check_hmc_diagnostics()`. The values of the
  checks are returned in the `diagnostics` attribute. If convergence cannot be
  assessed, for example for models fitted with variational inference or with
  `brms::brm_multiple()`, `FALSE` is returned with a message (#619).

* `is_converged()` now supports `coxph` models from *survival*. Before, it did
  not work for these models. It checks whether the model ran out of
  iterations and whether a coefficient is possibly infinite, as *survival*
  does when it fits the model. If a check fails, it returns `FALSE`. The
  attribute `diagnostics` shows the result of each check and the coefficients
  that are possibly infinite. For penalized models, the checks do not apply.
  For models with `ties = "exact"` or `tt()` terms, and in the other cases
  that the help page lists, `is_converged()` cannot recompute them. In these
  cases, it returns `FALSE`. Objects of other classes that inherit from
  `coxph`, such as `survival::clogit()` and `survey::svycoxph()`, are not
  supported (#1090).

## Bug fixes

* `find_parameters()` and `clean_parameters()` now work for multivariate
  *brms* models with addition terms in the response, such as `resp_weights()`
  or `trials()`. Before, `find_parameters()` returned empty elements with
  wrong response names, and `clean_parameters()` gave an error
  (easystats/bayestestR#700).

* If you use the hidden `variable` argument with `summary = TRUE`,
  `get_parameters()` for *brms* models no longer fails with the error
  `object 'parms' not found`. The summary then has the columns `Parameter` and
  `Estimate`.

* `get_predicted()` for zero-inflated *glmmTMB* models no longer fails for
  population-level predictions (`include_random = FALSE`, or a model without
  random effects) when the data object of the model call was changed or
  removed after the fit. Also, `get_predicted()` for zero-inflated *glmmTMB*
  and *pscl* models now accepts new data in the `newdata` argument. Before, it
  gave the error `formal argument "newdata" matched by multiple actual
  arguments`.

* `null_model()` now works when the model was fitted inside a function and its
  call uses a local object other than the data, for example
  `family = fam`. Before, it returned `NULL` for mixed models and gave an error
  for other models (easystats/performance#145).

* `find_random_slopes()` no longer reports a grouping factor or a *brms*
  correlation id as a random slope because its name is part of a slope name.
  An example is `p` in `(0 + Intercept | p | g)`. For *brms* models, the
  explicit `Intercept` is no longer a random slope. Before, `get_variance()` warned
  that random slopes were not present as fixed effects for these models.

* `get_modelmatrix()` with new `data` for *nlme* (`lme`, `gls`), `clmm` and
  *brms* models returns one row per data row. A row with a missing value or a
  factor level that the model data does not have holds `NA` values. Before, it
  was dropped. For *brms* models, an ordered factor given as a character
  vector in `data` gets the polynomial contrasts of the model.

* `get_predicted()` with new `data` for `lme` and `gls` models returns `NA` for
  rows with a missing value or a factor level that the model data does not have
  in a fixed-effect predictor, with a warning. If no row can be predicted, it
  returns `NULL` with a warning. Before, such a row made `get_predicted()`
  return the predictions for the model data. If `data` has no grouping column,
  `lme` models give population-level predictions, as for *lme4* models.

* `get_predicted()` for `lme` and `gls` models uses the `ci` argument, with or
  without new `data`. As for other models, the default `ci = NULL` returns no
  intervals or standard errors. Before, the interval level did not follow
  `ci`. For `lme` models, an explicit `level` argument is passed to
  `predict()`.

* The confidence intervals of `get_predicted()` for `lme` models, with or
  without new `data`, use one degree of freedom value for all rows, the
  smallest of the values per coefficient. Before, the values per coefficient
  were recycled against the predictions.

* `get_predicted()` with new `data` for `clmm` models returns `NULL` with a
  warning. Before, it returned the fitted values of the model data,
  transformed with the inverse link. If `data` has the rows of the model data
  and all of its predictor columns with the same values, the fitted values are
  still returned.

* `find_parameters()` for *brms* models again returns the standard deviations
  of smooth terms (`sds_*`) in the `smooth_terms` element. It also returns the
  simplex parameters of monotonic effects (`simo_*`) in the `simplex` element.
  For multivariate models, each response gets only its own parameters
  (easystats/parameters#1191)

* `get_data()` for `merModList` objects (package *merTools*) gets a `verbose`
  argument. If `verbose = FALSE`, it gives no warning that the data cannot be
  accessed.

* `get_variance()` for `nlme::lme()` models with a random-effect block that has
  no intercept, for example `random = ~ 0 + day | Dog / Side`:

  - For nested grouping factors, `get_variance()` returned `NULL`.

  - Without nested grouping factors, `var.slope` left out the first slope of
    the block, and `cor.slope_intercept` returned the correlation of two
    slopes as a slope-intercept correlation.

  `var.slope` of `nlme::lme()` models now leaves out the term named
  `(Intercept)`, not the first term of a block. So a block whose intercept is
  not its first term no longer reports the intercept as a slope. Such a block,
  for example from `nlme::pdBlocked()`, now also has its intercept variance in
  `var.intercept`.

* `get_variance()` for *lme4* models with uncorrelated random effects, for
  example `(1 + Days || Subject)`, now includes the random-slope variance in
  `var.random`. Before, `var.random` included only the random-intercept
  variance. For nested grouping factors, for example
  `(1 + Days || grp / subgrp)`, `var.random` was `NULL`. This also changes
  `performance::r2_nakagawa()` and `performance::icc()` for these models
  (#304, easystats/performance#428).

* `export_table(format = "html")` for a list of data frames now shows the
  caption of each data frame as the label of its row group, and the footer of
  each data frame as a source note. Before, a list `footer` or a mix of
  captioned and uncaptioned tables gave an error. Of the footers stored as
  attributes, only the first one was kept, and a list `caption` became one
  title. If any data frame in the list has a `Component`, `Effects`, `Group`
  or `Response` column, the old output stays, but a list `footer` no longer
  gives an error (#631).

* `export_table(format = "html")` for a single data frame with a list footer
  (a multi-line, colored footer) gave an error. The parts of the footer are
  now joined into one source note, as in text output.

* `export_table(format = "tt")` for a list of data frames now shows the
  caption of each data frame as the label of its row group, and the footer of
  each data frame as a note. Before, the captions were shown as an extra
  `group` column, the first caption became the title, and only the footer of
  the first data frame, or only `footer` if given, was kept. A list `caption`,
  or a mix of `table_title` and `table_caption` attributes, gave an error.
  An unnamed `column_names` vector names the shown columns. Before, it also
  needed a name for the `group` column.
  The old behavior stays if a data frame has one column, no rows, row groups
  (`indent_rows`) or a `Component`, `Effects`, `Group` or `Response` column,
  if the data frames have different column names, or if `by`, `row_groups` or
  `column_groups` is given. For these lists, each element of a list `footer`
  still gives one note. Each footer changes as for a single data frame. The
  color is not shown as a note, new lines at the start and end are removed,
  and an empty footer gives no note.

* `export_table(format = "tt")` for a single data frame now shows a footer as
  one note. A character vector gives its first string, because the second
  string is the color, and a list gives its strings joined. Before, each
  string was a note, so the color of a colored footer was shown as a second
  note, and a list footer with colors (a multi-line, colored footer) gave an
  error.

* `get_sigma()`, `get_variance()` and `get_variance_residual()` now support
  *brms* models where `sigma` has an intercept-only formula, for example
  `bf(y ~ x, sigma ~ 1)`. Sigma is the mean of the posterior draws of
  `b_sigma_Intercept`, back-transformed with the link function of `sigma`.
  Before, `get_sigma()` returned `NULL` and `get_variance()` returned a
  residual variance of 1. If `sigma` varies, for example with
  `sigma ~ (1 | g)`, `get_variance()` now returns no residual variance with a
  message, as it already did for `sigma ~ x` (#967).

* `find_parameters()`, `get_parameters()` and `clean_parameters()` now work for
  *blavaan* models with multiple groups and equality constraints, for example
  `group.equal = "loadings"`. Before, `find_parameters()` and
  `get_parameters()` failed with the error "replacement has length zero".
  `get_parameters(standardize = TRUE)` now gives the correct names for the
  posterior draws of all *blavaan* models. Before, the names were shifted,
  because the standardized draws also include the fixed parameters.
  `get_parameters()` now also works for *blavaan* models with user-defined
  parameters (`:=`) and returns their posterior draws. Before, it failed with
  the error "Arguments must be mcmc objects".
  `get_data(source = "mf")` now works for *lavaan* and *blavaan* models with
  multiple groups and returns the grouping variable as a column. Together,
  these fixes let `parameters::model_parameters()` work for multiple-group
  *blavaan* models (easystats/parameters#735).

* `get_varcov()` for *fixest* models now supports `vcov = "HC0"`. Before, it
  gave an error. The result is the same as
  `fixest::vcov_hetero(ssc = fixest::ssc(K.adj = FALSE))`, the
  heteroskedasticity-consistent matrix without the small-sample adjustment.
  For `"HC"`, `"HC4"`, `"HC4m"` and `"HC5"`, the error now names the
  supported types (#1251).

* `find_predictors()` and `find_variables()` no longer return the matrix of the
  *brms* autocorrelation terms `sar()`, `car()` and `fcor()`, for example `W`
  in `y ~ x + sar(W)`. This matrix is an object in `data2`, not a variable in
  the data. The grouping variable of `car()` is still returned.

* If *performance* is not installed, `get_variance()` now gives an error that
  asks you to install it. Before, it returned `NULL` without a message (#928).

* `n_obs(disaggregate = TRUE)` now returns the total number of trials for
  *brms* models with a `trials()` term in the response, for example
  `y | trials(size) ~ x`. Before, it ignored `disaggregate` and returned the
  number of data rows (#581).

* `get_variance()` and `get_variance_distribution()` returned a wrong
  distribution-specific variance for beta-binomial models with a probit or
  cloglog link. The cause was the back-transformation of the null-model mean,
  which always used the inverse logit. The mean now uses the inverse link of
  the model.

* `get_residuals()` for *gamlss* models now returns response residuals
  (observed minus expected values) for `type = "response"`. Before, it
  returned the normalized quantile residuals without a warning. The
  `mean()` function of the family gives the expected values. Thus, the result
  is also correct for families where `mu` is not the mean, for example
  zero-inflated families. For families without a `mean()` function, the
  residuals use `mu`, with a warning (#327).

* For a list of data frames, `caption = ""` (or `title = ""`) now makes
  `export_table()` remove the captions of all tables. This includes captions
  stored as attributes. `subtitle = ""` and `footer = ""` do the same for
  subtitles and footers. In a list of captions or footers, `""` removes the
  caption or footer of that table. Before this fix, `export_table()` still
  printed the attributes (#930).

* For univariate non-linear *brms* models (`nl = TRUE`), `find_parameters()`
  now returns the coefficients of the non-linear parameters of `mu` as
  conditional parameters, and their group-level terms as random parameters.
  Before, they were returned as auxiliary parameters. `find_auxiliary()` no
  longer returns the names of these non-linear parameters.
  `clean_parameters()` labels their coefficients like `summary()` from
  *brms*, for example `ult_Intercept`. The `effects`, `component` and
  `parameters` arguments of `get_parameters()` now select the coefficients of
  non-linear parameters. `get_varcov()`,
  `n_parameters(component = "conditional")` and
  `find_parameters(component = "location")` now include these coefficients,
  where they included none before. This also applies to non-linear parameters
  that are nested with `nlf()` (#1076).

* `get_parameters()` for *brms* models now returns `NULL` when no parameter
  matches the selection of `effects`, `component` and `parameters`. Before,
  depending on the selection, it returned the posterior draws of all
  parameters, an empty data frame, or an error (#1076).

* `get_modelmatrix()` for `clmm` models now uses the contrasts stored in the
  model, so `get_variance()` works for `clmm` models fitted with, for example,
  `contrasts = list(x = "contr.sum")`. For `clmm` models, a `data` argument is
  now used. For `clmm` and `brmsfit` models, factor variables in `data` get the
  levels of the model data, and the contrasts of the model are used. Thus, new
  data with only some of the levels gives the correct columns. A
  `contrasts.arg` list is now accepted for both model classes.

* If variables used in the model are missing from the data in the
  environment, but are columns of the model frame, `get_data()` now warns and
  takes the data from the model frame. This applies, for example, to `lm`,
  `glm`, `lmer`, `glmmTMB` and `gam` models. Variables are missing, for
  example, if you overwrite the data object after the model fit. Before this fix,
  `get_data()` silently dropped these variables. Then `get_predicted()`, and
  `get_loglikelihood()` for `glm` models, failed with "object not found"
  errors. Variables used only inside a transformation, like `a` in `log(a)`,
  are not detected (#1210).

* `get_modelmatrix()` for `lme` and `gls` models now uses the contrasts stored
  in the model instead of treatment contrasts. You set these contrasts with
  `contrasts = list(x = contr.sum)` in `lme()`, or with
  `options(contrasts = ...)` when you fit the model. If you provide `data`, its
  factor and character variables get the levels of the model data. Thus, new
  data with only some of the levels gives the correct columns.

* `get_modelmatrix()` for `lme` and `gls` models with new `data` now keeps the
  basis of terms like `poly()` from the model data. Thus, the columns match the
  fitted coefficients. If another package, like *MuMIn*, provides its own
  `model.matrix()` method for `lme` objects, `get_modelmatrix()` now still uses
  `data` and the model contrasts.

* `format_table` now correctly formats labels consistently when parameter names
  occurred multiple times.

* `get_data()` for `coxph` models no longer drops variable and value labels when
  `source = "mf"`.

* `find_parameters()` for *brms* models no longer drops parameters whose names
  start with the name of a distributional parameter, e.g. the coefficient
  `b_condition2` in a model with a (custom) distributional parameter `c`.

* `find_auxiliary()` no longer returns `"sigma"` for *brms* models that have no
  residual standard deviation, but auxiliary parameters whose names merely
  contain `"sigma"` (e.g. `"sigmadrift"` or `"sigmabias"` from custom families).

* `clean_parameters()` no longer assigns auxiliary parameters whose names
  contain `"sigma"` (like `"sigmabias"`) to the `"sigma"` component. These are
  now returned as their own component, which also fixes the related grouping in
  `parameters::model_parameters()`.

* `get_variance()` returned wrong values for `lme` models with nested random
  effects, for example `random = ~ 1 | Dog / Side`. It returned the standard
  deviations of the random effects instead of their variances, and it gave them
  the wrong group names. This also gave wrong results for `performance::icc()`
  and `performance::r2()`. For groups with three or more correlated random
  terms, the variances and covariances of the random effects were also wrong.

* `find_formula()` now returns the correct random effects formula for
  `nlme::lme()` and `MASS::glmmPQL()` models with a named list or a `pdMat`
  object in the `random` argument. Examples are `random = list(g = ~1)` and
  `random = pdDiag(~x)`. Before this fix, `find_random()` returned `NULL` for
  these models, and `parameters::model_parameters()` failed. If the `random`
  argument names an object that was defined inside a function, `find_formula()`
  also no longer fails.

* `get_predicted()` for `coxph` models with `predict = "survival"` now computes
  confidence intervals on the cumulative-hazard scale and back-transforms them,
  as `survival::survfit()` does by default. Before this fix, the intervals were
  symmetric around the survival probability and were not always between 0
  and 1.

* `get_predicted()` for `coxph` models with `predict = "expectation"` or
  `predict = "risk"` now returns standard errors and no longer warns that the
  delta method could not be applied.

# insight 1.5.4

## Bug fixes

* Fixed a bug where `get_statistic()` incorrectly extracted degrees of freedom
  (df) instead of the t value for `rlmerMod` models (*robustlmm*) after
  Satterthwaite degrees of freedom were cached (e.g., following `emmeans`
  calls).

* Fix failing CRAN checks.

# insight 1.5.3

## Changes

* `get_df()` now supports the `df_per_obs` argument for models of class `mmrm`,
  returning one degree of freedom per row of `data` instead of one per
  coefficient, using the method chosen when fitting the model.

* `model_info()` and `get_predicted()` now recognize the `ddm()`, `lba()` and
  `rdm()` custom *brms* families from package *cogmod* as reaction-time and
  choice models (`is_rtchoice`), alongside the already supported `lnr()`. Their
  predictions are hence split into the `"rt"` and `"response"` components,
  instead of being returned as a single interleaved vector.

* `get_datagrid()` gains a `weighted` argument, to create a smaller representation
  of large data grids, where multiple unique combinations of predictors are
  included only once, and a new `Weight` column indicates how often each
  combination appears in the original data. The related `n_bins` argument
  indicates how numeric values are represented in the reduced data grid.

* `format_ci()` gains a `separator` argument, to customize the separator for
  lower and upper CI values.

* `find_response()`, `find_predictors()`, and `find_variables()` now also work
  for objects from package *marginaleffects*.

* Preliminary support in `find_parameters()` for objects from package
  *marginaleffects*.

* `get_variances()` now passes `...` down to `VarCorr()`, which might be useful
  for Bayesian models (e.g. to return robust estimates using `robust = TRUE`).

* Added a documentation page for available `options`.

* Updated test-files for `htest` objects and fixed deprecated names.

## Bug fixes

* `null_model()` no longer fails for models whose offset is written inline in
  the formula with a nested-parenthesis expression followed by further terms
  (e.g. `y ~ x + offset(log(exposure)) + factor(year)`). The offset term is now
  extracted from the formula's language tree instead of by a paren-blind regex.

# insight 1.5.2

## Changes

* Major performance improvement for `compact_list` on very large, nested list
  objects.

* `get_varcov()` now explicitly works for `lavaan` objects.

## Bug fixes

* `get_modelmatrix()` now correctly handles *brms* models fitted with
  `0 + Intercept` formulas.

* `get_priors()` did not return degrees of freedom for Student's t-distribution
  for *rstanarm* models.

* Fixed issue in `get_variance()` for *brms* intercept-only models.

# insight 1.5.1

## Changes

* New support for `CmdStanFit` models from the *cmdstanr* package -
  `find_algorithm()`, `find_parameters()`, and `get_parameters()` now work with
  these models.

* `model_info()` now correctly detects t- and z-tests from package *BSDA*.

* `format_bf()` gains a `digits` argument.

* More informative error message when the response variable in `get_response()`
  is not present in the data.

* `format_table()` now also formats columns for tail and bulk ESS from Bayesian
  models.

* `get_data()` now supports objects of class `mira` from package *mice*.

* `get_varcov()` now supports the option `"fpc"` to apply finite population
  correction (Lai et al. 2018).

* Added a new function, `vcovFPC()`, to calculate finite-population-adjusted
  variance-covariance matrices.

## Bug fixes

* `has_intercept()` now correctly detects whether models from packages *fixest*
  and *lfe* have intercepts or not.

* The `vcov` argument in `get_varcov()` was ignored when `vcov` was of class
  `"dpoMatrix"` and did not return `TRUE` to `is.matrix()`.

# insight 1.5.0

## Changes

* New function, `get_simulated()`, to return simulated values from the response
  of regression models, which is comparable to posterior predictions from a
  model.

* Improved performance of `find_parameters()` for models from package *mgcv*
  that include random effects.

* Improved performance of `find_parameters()` and `get_statistic()` for models
  from package *mgcv* that include random effects.

* `get_predicted()` supports models from package *nestedLogit*.

* Added support for `aft`, `stpm2`, and `pstpm2` models from package *rstpm2*.
  `find_formula()`, `find_variables()`, `get_data()`, and `model_info()` now
  work with these flexible parametric survival models.

## Bug fixes

* Fixed issue with duplicated `link_inverse()` and missing `link_function()` for
  `phyloglm` models.

# insight 1.4.6

## Breaking Changes

* Revised weighted residuals (`get_residuals(weighted = TRUE)`) to be in line
  with R 4.6.0, which now returns weighted working residuals for `glm` objects.

# insight 1.4.5

## Changes

* `find_predictors()`, `find_variables()`, and `get_data()` now work with
  tidymodels workflow objects (#1161).

* Improve performance for `is_empty_object()` for large data frames (which, in
  turn, should improve performance of many other functions relying on this
  helper-function, including from other packages).

## Bug fixes

* Disabled test for the *feisr* package, which currently seems to be broken.

* Fixes issue where `get_datagrid()` failed on random effects with tokens in `by`.

# insight 1.4.4

## Bug fixes

* Fixed issue with `is_converged()` due to changes in *lme4* package.

* Fixed issue in `get_data(source = "mf")` for models from package *fixest*
  when `lean` was set to `TRUE` in the model call.

# insight 1.4.3

## Changes

* Added support for models from package *lcmm* (`lcmm`, `externVar`).

* Support for objects from the *modelbased* package. This includes methods for
  `get_parameters()`, `get_statistic()`, `get_df()`, `get_varcov()`,
  `find_formula()`, `find_parameters()`, `find_statistic()`, and `get_call()`.

* Better formatting for p-values-columns from equivalence tests from other
  packages.

* `format_value()`, `format_number()`, and `export_table()` gain a `big_mark`
  argument to format numbers with thousands separators (e.g., `1,234,567.89` or
  `1 234 567.89`). This makes large numbers more readable in tables and formatted
  output. When `big_mark` is provided, scientific notation is suppressed for
  large numbers to show the full value with separators.

* Improved support for models from package *survey*. This includes a dedicated
  `source` argument for methods such as `get_data()`, `get_weights()`,
  `find_weights()`, or `get_response()`, to specify whether the data should be
  extracted from the model frame of the survey design object (`"mf"`), which is
  usually equivalent to the original data, or from the data that can be extracted
  from the model-object in the environment (`"environment"`) , which usually
  includes processed variables (like the `"(weights)"` variable for weights).

* `get_df()` now supports Kenward-Roger and Satterthwaite degrees of freedom
  for models from package *glmmTMB*. This requires package version 1.1.3.

## Bug fixes

* Fix CRAN check failures.

* Fixed issue in `get_data()` for models from package *survey*.

* Fixed issue in `get_modelmatrix()` when the `data` argument was provided
  and contained columns with only missing values.

# insight 1.4.2

## Bug fixes

* Fix CRAN failures for Mac OS R-old-release.

# insight 1.4.1

## Changes

* `get_varcov()` now supports robust variance-covariance matrices for models
  of class `glmmTMB` (package *glmmTMB*). The argument `vcov` can be used to
  specify the robust variance-covariance matrix function. Furthermore, the
  `component` argument gains the `"full"` option, to return the full
  variance-covariance matrix, including the random effects (theta parameters).

* `format_table()` now also formats ROPE columns for superiority and inferiority.

* `format_table()` protects integer columns for non-specific column types.

* The `numerics` argument in `get_datagrid()` gains two new options, `"integer"`
  and `"mode"`, to either return the rounded mean or the most frequent value of
  a numeric vector.

* Modified code base to address changes in the *marginaleffects* package from
  version 0.29.0 onwards.

## Bug fixes

* Fixed issue with `find_formula()` with *mhurdle* models.

# insight 1.4.0

## Breaking changes

* `apply_table_theme()` was removed, since it was an experimental feature that
  is no longer used in any package.

## Changes

* `display()`, `print_md()` and `print_html()` get a `.table` method.

* `get_predicted()` now supports `chisq.test()`, and returns the expected
  frequencies.

* `export_table()` gains better support for the _tinytable_ package. Use
  `format = "tt"` to export tables into the tinytable-format. This can also
  be used with grouped tables, i.e. `by = "group"`.

* `export_table()` gains arguments `row_groups` and `column_groups`, to
  group rows and columns in the exported table. Column groups currently only
  work for `format = "tt"`.

* If arguments `title`, `subtitle` and `footer` in `export_table()` are set to
  an empty string `""`, no titles/subtitles/footers are printed, even if present
  as attributes.

* Added a `.lavaan` method for `is_converged()`.

* The formerly internal function to extract various information about mixed
  models is now exported as `get_mixed_info()`.

## Bug fixes

* Fixed issue with models of class `selection` with multiple response
  variables.

* Fixed issue in `get_datagrid()` for factors with `=` in their levels.

* Fixed issue in `find_random()` for multivariate response models of class `brms`
  with special response options.

* Fixed issue in several functions for certain betareg-models that contained
  a `"mu"` component instead of `"mean"`.

* Fixed CRAN check issues on M1 Macs.

# insight 1.3.1

## Changes

* New function `get_model()` to extract the model object from an arbitrary
  object, if the model object is stored as attribute of the parent object.

* The `range` argument in `get_datagrid()` gets a new option, `"pretty"`, to
  create a range of pretty values.

* `get_predicted()` now supports models of class `glmtoolbox::glmee`.

* `get_predicted()` supports predicting the class membership for models from
  package *brms* with `mixture()` family, using `predict = "classificaton"`.

* `get_predicted()` supports predicting the outcome by class membership for
  models from package *brms* with `mixture()` family, using `predict = "link"`.

* `get_residuals()` gets a method for objects from `parameters::factor_analysis()`,
  `psych::fa()`, `psych::omega()` and `psych::principal()`.

* `model_info()` returns `$is_mixture` to identify finite mixture models.

* Better support for models of class `sdmTMB`.

* Improve efficiency of `clean_parameters()` for more complex *brms* models.

## Bug fixes

* Fixed issue in `get_df()` for models from package *afex*.

* Fixed issue in `clean_names()` for *brms* models with `mm()` in formula.

* Fixed issue in `get_data()` for *brms* models with `mmc()` in formula.

* Fixed issue in `get_statistic()` for objects of class `aov`.

# insight 1.3.0

## Breaking Changes

* The default option `"all"` for the `effects` argument of `find_parameters()`
  and `get_parameters()` for models from package *brms* and *rstanarm* has a new
  behaviour and only returns fixed effects and random effects variance components,
  but no longer the group level estimates. Use `effects = "full"` to return
  all parameters. This change is mainly to be more flexible and gain more
  efficiency for models with many parameters and / or many posterior draws.

## New functions

* `is_bayesian_model()` as a convenient shortcut to check whether a model is
  Bayesian or not.

## Changes

* Revised wording for alerts from `get_variance()`.

* The `effects` argument of `find_parameters()` and `get_parameters()` for
  models from package *brms* and *rstanarm* get two new options, `"grouplevel"`
  and `"random_variances"`, to return only random effects variance components, or
  group level effects. This is more efficient especially for models with many
  samples and many parameters. Additionally, a `variable` argument can be passed
  to `get_parameters()`, which is in turn passed to `as.data.frame()`, to
  extract parameters more efficiently.

* The `by` argument in `export_table()` now also splits tables when format is
  not `"html"`.

## Bug fixes

* Fixed issue in `find_formula()` for models of class `barts` (package *dbarts*),
  when formula was abbreviated using `y ~ .`.

# insight 1.2.0

## Breaking Changes

* The handling of `brms` models in `find_parameters()`, `find_formula()` or
  `clean_parameters()` (and other functions) should now systematically take
  the many possible distributional parameters into account, identifying the
  different types of them, and assigning them to own values in the
  `Component` columns. *insight* should now be flexible enough to also cope
  with user-defined variables that have been modelled as distributional
  parameters.

* To be consistent with the naming pattern from package `brms`, all elements
  related to distributional parameters now returns exactly that "dpar" name.
  This means that, for instance, `find_formula()` no longer returns an element
  named `$zero_inflated`, but instead `$zi`. This only applies to models from
  `brms`! All other packages are not affected by this breaking change.

## Changes

* `find_random()` and `find_random_slopes()` now also extract random effects
  names from auxiliary components.

* `find_random()` and `find_random_slopes()` now include random effects from the
  dispersion component for models from package *glmmTMB*.

* `clean_parameters()` for brms-models now assigns auxiliary parameters to their
  related `Component` and overwrites former assignments to `"conditional"`.

* `format_table()` now includes more effect sizes when formatting column names.

* `get_datagrid()` now allows named vectors for arguments `length` and `range`,
  to match values with target variables defined in `by`.

* `get_datagrid()` gets a `protect_integer` argument, to allow a spread of
  values from minimum to maximum of length `length`, also for integer values.

* `export_table()` gets an argument `column_names`, to change the column names
  of the exported table.

* `model_info()` gains a `response` argument for classes that can be multivariate
  response models that return multiple lists of model information (currently,
  Stan models from *rstanarm* and *brms*). If not `NULL`, only the information
  for one of the response variables is returned.

* Creating a range of values in a `get_datagrid()` using `by` was now simplified
  and works like regular R syntax, e.g. `by = "mpg = 20:50"`.

* `get_predicted()` for models of class `brmsfit` now supports Wiener models
  or similar so called "decision models", that simultaneously model, e.g.,
  reaction times and (discrete) choices.

* `get_predicted()` no longer throws warnings for models of class `brmsfit`
  when distributional are predicted.

* `find_offset()` gets an `as_term` argument, which returns the offset as term,
  including possible transformations.

* Token-option `"quartiles2"` was removed and option `"quartiles"` now produces
  the three quartile values (lower hinge, median, upper hinge). The former
  option of `"quartiles"` that included minimum and maximum was identical to the
  already existing `"fivenum"` option.

* New function `find_auxiliary()`, which is a small helper to extract all
  distributional parameters that were used in models from package *brms*.

* `display()`, `print_md()` and `print_html()` get methods for matrix- and
  array objects.

* Cleaning / revising package documentation.

## Bug fixes

* `null_model()` now correctly calculates the null-model based on the data that
  was used to fit the model (model frame), which can lead to different results
  when the original data contained missing values.

* Fixed issue for `get_predicted()` with multivariate response models.

# insight 1.1.0

## Breaking Changes

* `get_datagrid()` no longer creates fractional parts when creating a range of
  values for numeric variables that are integers.

## Changes

* `get_datagrid()` now includes a dummy column for model weights (values `NA`),
  to work with models that used weights.

* `get_datagrid()` gets a `digits` argument, to round numeric representative
  values.

* Argument `ci_digits` defaults to `digits` in `format_table()`.

* `format_table()` gets a `select` argument, which can be used to select columns
  and column layout in a glue-like style.

* `find_response()` now also works for _tidymodels_ workflows.

* `get_transformation()` and `find_transformation()` now also detect
  log-transformation with logarithmic base.

## Bug fixes

* Fixed issue in `find_formula()`, `find_response()` and `find_predictors()` for
  multinomial `gam` models from package *mgcv*.

# insight 1.0.2

## Changes

* `get_datagrid()` gives a more informative error message when a variable
  specified in `by` was not found in the data.

* The `by` argument in `get_datagrid()` gets a new token-option, `"[sample <number>]"`,
  to draw a random sample of values.

## Bug fixes

* Option `"terciles"` and `"terciles2"` in `get_datagrid()` were swapped, i.e.
  `"terciles"` was doing what was documented for `"terciles2"` and vice versa.
  This has been fixed.

* `include_random` in `get_datagrid()` now works for nested random effects, i.e.
  for more than one group level factor in the random effects.

* Fixed issue in `get_varcov()` for models of class `brmsfit` that included
  monotonic effects.

# insight 1.0.1

## General

* Support for models of class `oohbchoice` (package *DCchoice*).

* `format_table()` gets a `stars_only` argument, to format p-value columns to
  contain only significance stars.

* `get_predicted()` for brms-models with categorical family now includes the
  data of the data grid in the returned predictions, for better orientation.

## Bug fixes

* Fixed issues due to latest *mice* updates.

* Fixed typo in `get_parameters.glmmadmb()`, which was erroneously renamed into
  `get_parameters.glmmTMBadmb()`.

* Fixed issues in `find_predictors()` and `has_intercept()` for *brms* models
  with `0 + Intercept` formula notation.

* Fixed issues in `get_statistic()` for models of class `fixest` from
  negative-binomial families.

* Fixed issue with `as.numeric()` method for `get_sigma()`.

* `get_datagrid()` now only returns valid levels when `include_random = TRUE`
  and group-level factor in random effects is numeric.

# insight 1.0.0

## Breaking changes

* All deprecated arguments have been removed.

* The `table_width` argument in `export_table()` now defaults to `"auto"`.

## General

* `get_transformation()` can now deal with any power-transformation, and also
  returns results for divisions (scaled response) and Box-Cox transformations.

* `find_transformation()` and `get_transformation()` now also detects use of
  divisions, like `x/3` or Box-Cox transformations (like `(x^lambda - 1) / lambda`).

* `find_transformation()` and `get_transformation()` get a `include_all` argument,
  to check all model terms for transformations.

* `get_dispersion()` is now an exported function.

* Updated `get_varcov()` (and related documentation) to support new covariance
  matrix estimation methods from the **sandwich** package.

* New function `validate_argument()` as a replacement for `match.arg()` with
  more informative error message.

* The function to calculate the corrections for likelihood-values when the
  response-variable is transformed is now exported as `get_likelihood_adjustment()`.

* `export_table()` can now split tables into more than three tables when
  `table_width` is used (formerly, the maximum number of split tables was three).

* Changed (improved) formatting for parameter tables in `export_table()`, when
  `format = "html"`. Rows are indented, and group headers are emphasized in
  italic.

* `formula_ok()` now also checks for syntactically invalid variable names.
  Furthermore, argument `checks` now allows to specify for which possibly
  problematic formula notation should be checked.

* `format_value()` gains a `decimal_point` argument, to change the decimal point
  in output conversion.

* `format_bf()` with `stars = TRUE` uses the `°` symbol for inferiority
  (evidence *against* the comparison).

* Added support for `coxph.panel` models.

* Added support for models of class `asym` (package *panelr*).

* Overhaul of documentation for the package-functions.

## Bug fix

* `clean_parameters()` now uses the correct labels for the random effects
  variances (`"SD/Cor"` has changed to `"Var/Cov"`).

* When `get_data()` could not properly evaluate the subset of a data set, it
  now returns an informative warning and no longer errors.

* Fixed inaccuracy in `get_sigma()` for models of class *brmsfit*.

* Fixed issues in `get_variance()`  for models of class *brmsfit* when the
  sigma-parameter was directly modeled.

* Fixed issue in `compact_character()` and `compact_list()` for date-variables.

* Fixed edge case in `find_transformation()` for simple log-transformation of
  the response variable.

* Fixed issue for `model_info.averaging()`.

# insight 0.20.5

## General

* `get_datagrid()` can now be used to extract the "grid" information from
  `{emmeans}` and `{marginaleffects}` outputs.

* Arguments `na.rm` and `na_rm` are deprecated throughout the package's functions.
  Instead, use `remove_na`.

## Bug fixes

* Fixed rendering issue of the example in `?insight::display`.

* Fixed issues due to recent changes in the *glmmTMB* package.

# insight 0.20.4

## New supported models

* Support for models of classes `glm_weighit`, `multinom_weightit` and
  `ordinal_weightit` (package *WeightIt*).

## Changes

* `null_model()` and `formula_ok()` now warn when indexed data frames, such as
  `df[, 5]`, are used as response variable in the formula, as this can lead to
  unexpected results.

* Minor improvements to `link_function()` and `link_inverse()`.

## Bug fixes

* Fixed regression from latest fix related to `get_variance()` for *brms* models.

* Fixed issue in `link_function()` and `link_inverse()` for models of class
  *cglm* with `"identity"` link, which was not correctly recognized due to a
  typo.

# insight 0.20.3

## Changes

* `get_df()` now supports more model classes.

* `get_variance()` gives an informative error if no mixed model is provided.

## Bug fixes

* Fixed issue in `find_formula()`, `find_predictors()` and `find_variables()`
  for models from package *brms* with custom formulas.

* Fixed issues in `find_response()` for *brms* models with `mi()` function in
  the response variable.

* Fixed issue in `get_variance()` that could lead to recursive calls for
  *brms* models, resulting in "infinite" resampling of the model.

* Fixed issue in `check_if_installed()` that erroneously tried to guess the
  minimum required package version based on the SUGGEST field of the _insight_
  package, instead of the package that was calling the function.

* Fixed issue in `get_modelmatrix()` for models from package *brms* with
  special functions in the formula (like `mo()`).

* Fixed issue in `ellipses_info()` when this function was called from `do.call()`.

* Fixed issue with formatting unicode-symbols, where a wrong unicode-character
  was used for "Omega". Furthermore, Omega2 and Eta2 are now correctly converted.

# insight 0.20.2

## New supported models

* Support for models of class `glmgee` (package *glmtoolbox*).

* Support for models of class `svy2lme` (package *svylme*).

## General

* Massive overhaul of `get_variance()`. The function should be now more
  accurate for different distributional families, in particular for
  mixed regression models with Beta family.

* Improved accuracy of singularity-checks in `get_variance()`.

* `get_variance()` gets a few new arguments:

  * `null_model`, to provide a null-model to be used for the calculation of
    random effect variances. If `NULL`, the null-model is computed internally.
    This argument is optional, but may be useful to save time, or when the
    null-model cannot be calculated internally.

  * `approximation`, indicating the approximation method for the
    distribution-specific (observation level, or residual) variance.

  * `model_component`, for models that can have a zero-inflation component,
    specify for which component variances should be returned. By default, both
    the conditional and the zero-inflation component are taken into account.

* `format_alert()` and `format_warning()` get an `immediate` argument, to output
  warnings immediately.

* `find_terms()` and `find_transformation()` now better cope with inverse
  transformations of the response value, such as `1/y`.

* `get_transformation()` now returns more transformations for power-transformed
  response variables.

* `model_info()` for `MixMod` objects from package *GLMMadaptive* now recognize
  zero-inflation and hurdle models for custom families.

## Bug fixes

* `null_model()` now correctly handles zero-inflated models from package
  *glmmTMB*.

* Fixed issue in `null_model()` for models from package *GLMMadaptive*.

* Fixed issues in `link_inverse()` and `link_function()` for models of class
  `gamlss` from `LOGNO()` family.

# insight 0.20.1

## Bug fixes

* Fixed possible memory allocation issues when the deprecated argument `at` was
  used in `get_datagrid()`.

# insight 0.20.0

## Breaking

* Arguments named `group`, `at`, `group_by` and `split_by` will be deprecated
  in future releases of _easystats_ packages. Please use `by` instead. This
  affects following functions in *insight*:

  * `export_table()`
  * `get_datagrid()`
  * `print_parameters()`

## Bug fixes

* Fixed errors in CRAN checks.

# insight 0.19.11

## General

* More informative error message for `get_varcov()` when the requested
  `vcov`-function failed.

## Bug fixes

* Fixed issue with `get_data()` for `coxme` models when `source` was set to
  `"modelframe"`.

# insight 0.19.10

## Bug fixes

* Functions like `find_variables()` or `clean_names()` now support multi-membership
  formulas for models from *brms*.

* Updated tests to work with the latest changes in *glmmTMB 1.1.9*.

# insight 0.19.9

## New supported models

* Support for models of class `serp` (package *serp*).

## General

* `standardize_names()` now also recognizes column `s.value` from objects of
  package *marginaleffects*.

## Bug fixes

* Fixed issue in `find_predictors()` for models with splines (`s()`), where
  number of dimensions was indicated with a variable, not a number.

* `format_ci()` now works for factors and character vectors again.

* Fixed issues with latest release of _tinytable_.

* Fixed issues with latest release of _PROreg_.

# insight 0.19.8

## General

* Removed deprecated arguments in `get_data.mmrm()`.

* Improved support for models of class `rqs` (package *quantreg*).

* Revised test to address forthcoming changes in the *pscl* package.

## Bug fixes

* Fixed issue in `get_loglikelihood()` for glm-models with binary outcome, where
  levels were defined in reversed order.

* Fixed issue in `find_formula()` for models of class `glmmPQL` (package *MASS*).

* Fixed issue in `find_formula()` for models of class `gam` (package *mgcv*) for
  the `"gaulss"` family.

* Fixed issue in `get_variance()` for *glmmTMB* models with `family = "ordbeta"`.

* Fixed issue in `model_info()` with correctly detecting multivariate vgam/vglm
  models.

# insight 0.19.7

## General

* Support for objects of class `ggcomparisons` from `ggeffects::hypothesis_test()`.

* `brms::gr()` is now supported, meaning that functions like `get_data()` or
  `find_predictors()` now also work for models with group-specific random effects.

* Fix CRAN check issues due to the last *fixest* update.

## Changes to functions

* `get_varcov()` for models of class `pgmm` (package *plm*) now also supported
  robust variance-covariance matrices (i.e. argument `vcov`).

## Bug fixes

* Fixed issue in `find_predictors()` for survival models with `strata()`,
  containing more that one variable.

* Fixed issue in `model_info()`, where in some cases logistic regression models
  were erroneously considered as `"bernoulli"` models.

* Fixed issue in `find_formula()` for models of class `gamlss` when the `random()`
  function was used with namespace in the formula (i.e. `... + gamlss::random()`).

* `model_info()` now detects models with zero-inflation part from package
  *glmmTMB* when models have truncated-families but no `ziformula`.

# insight 0.19.6

## General

* Improved documentation for `get_predicted_ci()`.

## Changes to functions

* `model_info()` now recognized ordered beta families.

* `find_formula` and `get_response` for `nestedLogit` models gain a `dichotomies`
  argument, to return values for the dichotomies used to fit the model.

## Bug fixes

* `find_transformation()` better detects power-transformation of the response
  variable.

* Corrected return value from `find_statistic` for `nnet::multinom()` models.

* `clean_parameters()` did not return the `"clean_parameters"` class attributes
  for some object. This caused issued in upstream packages.

* Fixed issue in `model_info()`, which did not correctly detect "Bernoulli"
  property for some models classes (like `glmmTMB` or `glmerMod`).

# insight 0.19.5

## Bug fixes

* Fixed critical issue with `check_if_installed()` for old R releases.

# insight 0.19.4

## Changes to functions

* `get_predicted()` now accepts `predict = "link"` for gaussian models with
  log-link (i.e. `glm(..., family = gaussian("log"))`), to return predictions
  on the link scale.

* `check_if_installed()` now automatically checks the package DESCRIPTION file to
  determine the correct minimum version required.

## Bug fixes

* Fixed issue with invalid multibyte strings in `trim_ws()`.

* Fixed issue in `find_statistic()` for models from package *fixest*.

# insight 0.19.3

## Breaking changes

* `standardize_column_order()` has changed the position when re-ordering Bayes
  factors, ROPEs and ESS / Rhat (mainly relevant for Bayesian models).

## Changes to functions

* `standardize_names()` and `standardize_column_order()` now also recognize the
  `"response.level"` column name.

* `get_data()` for _lavaan_ models is now more stable at retrieving model data
  when this is not available in the environment.

* `find_terms()` gets an `as_term_labels` argument, to extract model terms
  from the formula's `"term.labels"` attribute. This is closer to the behaviour
  of `stats::terms()`, but may be insufficient, e.g. for mixed models.

## Bug fixes

* `get_random()` now returns the same observations as `get_data()` and correctly
  removes missing values from the data before returning it.

* `find_parameters()` for marginal effects ignores the `"s.value"` column (which
  was added in a recent update).

* Fixed issue in `get_response()` for _brms_ models with `trunc()` function in
  the response variable.

# insight 0.19.2

## Breaking changes

* The minimum needed R version has been bumped to `3.6`.

* `download_model()` no longer errors when a model object could not be downloaded,
  but instead returns `NULL`. This prevents test failures, and allows to skip
  tests when the return value of `download_model()` is `NULL`.

## General

* Improved support for `mclogit` models (package *mclogit*) and `mipo` objects
  (package *mice*) for models with ordinal or categorical response.

## New supported models

* `phylolm` and `phyloglm` (package *phylolm*), `nestedLogit` (package *nestedLogit*).

## Bug fixes

* Fixed issue in `get_variance()` for *glmmTMB* models with rank deficient
  coefficients.

* Fixed issues in `get_weights()` for `glm` models without weights and `na.action`
  not set to default in the model call.

* `clean_names()` now also removes the `relevel()` pattern.

* Fixed issue in `model_info()` for models of class `gamlss`.

* Fixed problems preventing `get_data()` from locating data defined in
  non-global environments.

* Fixed issue in `get_predicted()` for variables of class numeric matrix created
  by `scale()`, which were correctly handled only when `get_data()` failed to
  find the data in the appropriate environment.

* Fixed issue in `model_info()` for `gee` models from `binomial` families.

# insight 0.19.1

## New supported models

* `hglm` (package *hglm*).

## Changes to functions

* Minor improvements to `get_data()` for `t.test()`.

* `format_value()` gets a `lead_zero` argument, to keep or drop the leading
  zero of a formatted value, as well as arguments `style_positive` and
  `style_negative` to style positive or negative numbers.

* `format_table()` now also formats columns named `SGPV` (second generation
  p-values) as p-values.

* Functions for models of class `clm` (like `find_formula()`, `find_variables()`,
  `get_data()` etc.) now also include variables that were defined as `scale` or
  `nominal` component.

## Bug fixes

* Fixed issue in `get_data()` for results from `kruskal.test()`.

* Fixed issue in `find_weights()` for models of class `lme` and `gls`.

* Fixed issue in `get_datagrid()` for models with multiple weight variables.

# insight 0.19.0

## New supported models

* `mmrm` (package *mmrm*), `flac` and `flic` (*logistf*)

## Breaking changes

* `get_data()` was revised and now always tries to recover the data that was
  used to fit a model from the environment. If this fails, it falls back to
  recovering data from the model frame (the former default behaviour).
  Furthermore, the `source` argument can be used to explicitly force the old
  behaviour: `source = "mf"` will try to recover data from the model frame first,
  then possibly falling back to look in the environment.

## New functions

* `n_grouplevels()`, to return random effect groups and number of group levels
  for mixed models.

## Changes to functions

* `get_datagrid()` preserves all factor levels for factors that are hold constant
  at their reference level. This is required to work together with
  `get_modelmatrix()` when calculating standard errors for `get_predicted()`.

## Bug fixes

* Fixed but in `get_modelmatrix()` handling of incomplete factors which
  sometimes had downstream implications for numerical results in the uncertainty
  estimates produced by `get_predicted()`.

* Fixed minor issues for HTML tables in `export_table()` when model parameters
  were grouped.

* Fixed issue with incorrect back-transforming in `get_data()` for models with
  log-transformed variables.

* Fixes issue in `compact_list()`.

* `has_single_value()` now returns `FALSE` when the object only has `NA` and
  `na.rm = TRUE`.

* Fixed issue in `get_parameters()` for gam-models without smooth terms, or with
  only smooth terms and removed intercept.

# insight 0.18.8

## Bug fixes

* Fixed test due to changes in the _performance_ package.

# insight 0.18.7

## General

* Minor revisions to `get_predicted.glmmTMB()` due to changes in behaviour
  of `predict.glmmTMB()` for truncated-family models since _glmmTMB_ 1.1.5.

* New function `has_single_value()` that is equivalent to `length(unique()) == 1`
  (or `n_unique() == 1`) but faster.

## Changes to functions

* `ellipses_info()` now includes an attribute `$is_binomial`, which is `TRUE`
  for each model from binomial family.

## Bug fixes

* Fixed behaviour of the `at` argument in `get_datagrid()`.

* Fixed issue for accessing model data in `get_datagrid()` for some edge cases.

# insight 0.18.6

## New supported models

* Support the *logitr* package: `get_data()`, `find_variables()` and more.

## Bug fixes

* Better detection of unicode-support, to avoid failures when building
  vignettes.

* `get_predicted()` now correctly handles variables of class numeric matrix
  created by `scale()`, which fixes a bug in `performance::check_model()`
  (easystats/performance#432).

* Fixed issue with `iterations` argument in `get_predicted()` with _brms_
  models.

# insight 0.18.5

## Breaking

* `get_df(type = "satterthwaite")` for `lmerMod` objects now return degrees of
  freedom per parameter, and no longer per observation. Use `df_per_obs TRUE`
  to return degrees of freedom per observation.

## New functions

* `safe_deparse_symbol()` to only deparses a substituted expressions when
  possible,which increases performance in case many calls to
  `deparse(substitute())`.

## Changes to functions

* `format_table()` gets a `use_symbols` argument. If `TRUE`, column names that
  refer to particular effectsizes (like Phi, Omega or Epsilon) include the related unicode-character instead of the written name. This only works on Windows for
  R >= 4.2, and on OS X or Linux for R >= 4.0.

* The `stars` argument in `format_table()` can now also be a character vector,
  naming the columns that should include stars for significant values. This is
  especially useful for Bayesian models, where we might have multiple columns
  with significant values, e.g. `"BF"` for the Bayes factor or `"pd"` for the
  probability of direction.

* `get_df()` gets more `type` options to return different type of degrees of
  freedom (namely, `"wald"` and `"normal"`, and for mixed models, `"ml1"`,
  `"betwithin"`, `"satterthwaite"` and `"kenward-roger"`).

* `standardize_names()` now recognized more classes from package _marginaleffects_.

* Minor improvements to `find_parameters()` for models with nonlinear formula.

* Minor speed improvements.

## Bug fixes

* Fixed issue in `get_data()` for models of class `plm`, which accidentally
  converted factors into character vectors.

* Fixed issue with column alignment in `export_table()` when the data frame
  to print contained unicode-characters longer than 1 byte.

* Correctly extract predictors for `fixest::i(f1, i.f2)` interactions (#649 by
  @grantmcdermott).

# insight 0.18.4

## Changes to functions

* `model_info()` now includes information for `htest` objects from
  `shapiro.test()` and `bartlett.test()` (will return `$is_variancetest = TRUE`).

## Bug fixes

* Fixed issue in `get_data()` which did not correctly backtransform to original
  data when terms had log-transformations such as `log(1 + x)` or `log(x + 1)`.

* Fixed CRAN check issues.

# insight 0.18.3

## New functions

* `format_alert()`, `format_warning()` and `format_error()`, as convenient
  wrappers around `message()`, `warning()` or `stop()` in combination with
  `format_message()`. You can use these funcionts to format messages, warnings
  or errors.

## Changes to functions

* `get_predicted()` for models of class `clm` now includes confidence intervals
  of predictions.

* `format_message()` gets some additional formatting features. See 'Details'
  in `?format_message` for more information and some current limitations.

* `format_message()` gets an `indent` argument, to specify indention string
  for subsequent lines.

* `format_table()` now merges IC and IC weights columns into one column (e.g.,
  former columns `"AIC"` and `"AIC_wt"` will now be printed as one column, named
  `"AIC (weights)"`). Furthermore, an `ic_digits` argument was added to control
  the number of significant digits for the IC values.

* `print_color()` and `color_text()` now support bright variants of colors and
  background colors.

* `get_datagrid()` gets more options for `at` and `range`, to provide more
  control how to generate the reference grid.

* `get_data()` for models of class `geeglm` and `fixest`now more reliably
  retrieves the model data.

## New supported models

* Support for models of class `mblogit` and `mclogit`.

## Bug fixes

* Fixed issues with wrong attribute `adjusted_for` in `insight::get_datagrid()`.

* Fixed issue (resp. implemented workaround) in `get_data.iv_robust()`, which
  failed due to a bug in the _estimatr_ package.

* Fixed issue where `get_predicted()` failed when data contains factors with
  only one or incomplete levels.

* Fixed issue in `get_predicted()` for models of class `mlm`.

* Fixed issue where `get_predicted()` failed to compute confidence intervals
  of predictions when model contained matrix-alike response columns, e.g. a
  response variable created with `cbind()`.

# insight 0.18.2

## New functions

* `format_percent()` as short-cut for `format_value(as_percent = TRUE)`.

* `is_converged()`, to check whether a mixed model has converged or not.

## Changes to functions

* `format_table()` gains an `exact` argument, to either report exact or rounded
  Bayes factors.

* `get_predicted()` gets a method for models of class `gamlss` (and thereby,
  `get_loglikelihood()` now also works for those model classes).

* `get_predicted()` now better handles models of class `polr`, `multinom` and
  `rlm`.

## Bug fixes

* Fixed test failures.

* Minor fixes to address changes in other packages.

# insight 0.18.0

## Breaking changes

* The `ci` argument in `get_predicted()` now defaults to `NULL`. One reason was
  to make the function faster if confidence intervals are not required, which
  was the case for many downstream usages of that function. Please set `ci`
  explicitly to compute confidence intervals for predictions.

* `get_data()` no longer returns logical types for numeric variables that have
  been converted to logicals on-the-fly within formulas (like `y ~ as.logical(x)`).
  Instead, for each numeric variable that was coerced to logical within a formula
  gets a `logical` attribute (set to `TRUE`), and the returned data frame gets
  a `logicals` attribute including all names of affected variables.

* `parameters_table()`, the alias for `format_table()`, was removed.

## Changes to functions

* `find_transformation()` and `get_transformation()` now also work for models
  where the response was transformed using `log2()` or `log10()`.

## Bug fixes

* `get_sigma()` for models from package _VGAM_ returned wrong sigma-parameter.

* `find_predictors()` for models from package _fixest_ that contained
  interaction terms in the endogenous formula part did not correctly return
  all instruments.

* Fixed formatting of HTML table footers in `export_table()`.

* Several fixes to `get_predicted()` for models from `mgcv::gam()`.

* The `component` argument in `find_parameters()` for `stanmvreg` models did
  not accept the `"location"` value.

* `null_model()` did not consider offset-terms if these were specified inside
  formulas.

* Argument `allow.new.levels` was not passed to `predict()` for
  `get_predicted.glmmTMB()`.

* `clean_names()` now works correctly when several variables are specified in
  `s()` (#573, @etiennebacher).

# insight 0.17.1

## New supported model classes

* `deltaMethod` (*car*), `marginaleffects`, `marginaleffects.summary`
  (*marginaleffects*)

## General

* `get_predicted()` now supports models of class `iv_robust` and `ivreg`.

* For `get_predicted()`, when both `type` and `predict` are given, `type`
  will overwrite `predict`. Note that this will print a message, because
  `predict` is the preferred argument.

* `get_varcov()` gains `vcov` and `vcov_args` arguments, to specify the
  variance-covariance matrix used to compute uncertainty estimates (e.g., for
  robust standard errors).

* `get_loglikehood()` improved handling of models from package *estimator*.

## Bug fixes

* Fixed bug in `get_data()` for model objects whose data needs to be recovered
  from the environment, and where the data name was a reserved word (e.g., named
  like an R function).

* The matrix returned by `get_varcov()` for models of class *bife* now returns
  row and column names.

* `find_offset()` did not find offset-terms for `merMod` objects when the
  offset was specified as `offset` argument in the function call.

# insight 0.17.0

## Breaking changes

* Arguments `vcov_estimation` and `vcov_type` in `get_predicted()`,
  `get_predicted_se()` and `get_predicted_ci()` are replaced by `vcov` and
  `vcov_args`, to have a more simplified and common interface to control
  robust covariance matrix estimation.

## General

* Improved performance for various functions, in particular `get_data()` and
  `model_info()`.

## New functions

* To check for names: `object_has_names()` and `object_has_rownames()`

* To work with lists: `is_empty_object()` and `compact_list()`

* To work with strings: `compact_character()`

* Further utility functions are `safe_deparse()`, `trim_ws()` and `n_unique()`.

## Changes to functions

* `export_table()` now better checks for invalid values of caption and footer
  for tables in HTML format, and silently removes, e.g., ansi-colour codes that
  only work for text-format.

* `get_data.coxph()` returns the original data frame instead of data with type
   coercion.

* `get_loglikelihood()` gets a `check_response` argument, to check if a model
  has a transformed response variable (like `log()` or `sqrt()` transformation),
  and if so, returns a corrected log-likelihood.

* `get_modelmatrix()` now supports *BayesFactor* models.

* `get_loglikelihood()` and `get_df()` now support more model classes.

* `get_predicted()` was improved for multinomial models from *brms*.

* `get_variance()` was improved to cover more edge cases of (more complex)
  random effect structures.

* `get_data()` now includes variables in the returned data frame that were
  used in the `subset` argument of regression functions (like `lm()`).

* In some edge cases, where `get_data()` is unable to retrieve the data that
  was used to fit the model, now a more informative error is printed.

* `ellipses_info()` now also accepts a list of model objects, is more stable
  and returns more information about the provided models (like if all fixed
  or random effects are the same across models, if all models are mixed models
  or null-models, etc.)

* `check_if_installed()` now works interactively and lets the user prompt
  whether to automatically update or install packages.

## Bug fixes

* Fixed incorrect column name conversion in `standardize_names()` for certain
  columns returned by `broom::glance()`.

* Fixed issue with correctly detecting Tweedie-models in `model_info()`.

* Fixed issue with `get_datagrid()` for *brms* models with monotonic factors.

* Fixed issue in `find_formula()` when argument `correlation` was defined
  outside of `lme()` and `gls()` (@etiennebacher, #525).

* Fixed issue with `get_data()` when back-transforming data from predictors
  that used `cos()`, `sin()` or `tan()` transformations.

# insight 0.16.0

## New functions

* `get_datagrid()`, to generate a reference grid, usually used when computing
  adjusted predictions or marginal means from regression models.

## Changes to functions

### `get_predicted()`

* `get_predicted()` was revised. Beside the four core options for the `predict`
  argument, it is now also possible to use any value that is valid for the
  model's `predict()` method's `type` argument.

* `get_predicted()` now supports more models (e.g., from packages like
  _GLMMadaptive_ or _survival_).

* `get_predicted()` is now more robust when calculating standard errors of
  predictions.

### Other functions

* `get_statistic()` and `find_statistic()` now support *htest* objects.

## General

* Various minor improvements.

# insight 0.15.1

## General

* Improved speed performance, especially for `get_data()`.

## Changes to functions

* `get_data()` for `coxph` models now returns the original factor levels for
  variables transformed with `strata()` inside formulas.

# insight 0.15.0

## Breaking changes

* Data management functions (like `reshape_longer()`, or `data_match()`) have
  been moved to the *datawizard* package.

* `get_data()` no longer returns factor types for numeric variables that have
  been converted to factors on-the-fly within formulas (like `y ~ as.factor(x)`).
  Instead, for each numeric variable that was coerced to factor within a formula
  gets a `factor` attribute (set to `TRUE`), and the returned data frame gets
  a `factors` attribute including all names of affected variables.

## New supported model classes

* Support for `bfsl` (*bfsl*)

## New functions

* New `standardize_column_order()` function can be used to standardize the
  column order in output dataframes.

## General

* Improved speed performance for some functions.

* Improved handling of table captions and footers in `export_table()`. See also
  the new vignette on exporting data frames into human readable tables here:
  https://easystats.github.io/insight/articles/export.html

* Revised `width` argument in `export_table()`, which now allows to set
  different column widths across table columns. See examples in
  `?export_table`.

* `export_table()` gets a `table_width` argument to split wide tables into
  two parts.

* `get_varcov()` for `MixMod` (package *GLMMadaptive*) was revised, and now
  allows to return a robust variance-covariance matrix.

* Added more `get_df()` methods.

## Bug fixes

* Fixed issues with manual sigma computation to handle dispersion models in
  `get_sigma()`.

* Fixed issue in `find_formula()` for `BayesFactor::lmBF()` with multiple random
  effects.

* Fixed issue in `get_parameters.BFBayesFactor()` with wrong sign of difference
  estimate for t-tests.

* Argument `width` in `format_value()` was ignored when formatting integer
  values and `protect_integers` was set to `TRUE`.

# insight 0.14.5

## New functions

* `find_transformation()` and `get_transformation()` to find or get any function
  that was used to transform the response variable in a regression model.

## General

* Improved support for models of class `sampleSelection`.

* Improved documentation.

* `get_modelmatrix()` now supports: `rms::lrm`

* `get_predicted()` supports: `MASS::polr`, `MASS::rlm`, `rms::lrm`, `fixest`,
  `bife::bife`, `ordinal::clm`.

* `get_predicted()` standard errors are often much faster to compute.

* `get_predicted()` supports models with "grouped" or "level" outcomes (e.g.,
  multinomial logit).

* `get_predicted()` handles factors better.

* Improved documentation

## Changes to functions

* `check_if_installed()` gains a `quietly` argument, if neither stopping nor a
  warning message for non-installed packages is requested.

* `get_predicted()`'s `predict` argument now accepts these values: "link",
  "expectation", "prediction", "classification", or NULL.

* `get_predicted()` accepts `predict=NULL`, which allows users to push a `type`
  argument through the `...` ellipsis, forward to the `predict()` method of the
  modelling package.

## Bug fixes

* Fixed issue with parameter names from *emmeans* objects in
  `get_parameters()`.

* Fixed issues with unknown arguments in `get_predicted()`.

# insight 0.14.4

## Bug fixes

* Fixed issues due to latest *brms* update.

# insight 0.14.3

## New supported model classes

* `systemfit` (*systemfit*)

## General

* Minor improvements for functions that support printing outputs.

## Changes to functions

* `get_predicted()` gains a new option, `predict = "response"` for binomial
  models.

* Improved stability of `get_variance()` when computing random-slope-intercept
  correlation with categorical random slopes.

* Improved `get_priors()` for *brms* models.

## Bug fixes

* Fixed issue in `get_data()` for *brms* models with auxiliary parameters.

* Fixed issue in `find_formula()` for *brms* models with auxiliary parameters.

* Fixed issue where `get_data()` for *htest* objects did not always preserve
  factors.

* Fixed issue in `format_table()` for ci-levels with longer fractional part.

# insight 0.14.2

## Changes to functions

* `check_if_installed()` gains a `minimum_version` argument, to check if an
  installed package is not older than the specified version number.

* The `package` argument in `check_if_installed()` is now vectorized, so you can
  check for multiple packages in one function call.

* Value formatting functions (like `format_value()` or `format_ci()`) can now
  round to significant digits using `digits = "signif"`.

## Bug fixes

* Fixed issue in `model_info()` with `stan_polr()` models.

* Fixed issue in `find_parameters()` for *brms* when model contained parameters
  for the priors on sigma.

* Fixed issue in `n_obs()` for `stats4::mle()` models.

* Fixed failing tests due to latest *fixest* update.

* Fixed issues due to latest *epiR* update.

# insight 0.14.1

## New functions

* Added several data management and preparation functions: `data_to_long()`,
  `data_match()`, `data_relocate()`, `data_restoretype()`, `force_numeric()`.

## New supported model classes

* Support for `pgmm` (*plm*)

## Changes to functions

* Improved handling of auxiliary parameters for *stanreg* models.

## Bug fixes

* Stability improvements to `get_predicted()`.

* Fixed issues when accessing information from an `afex_aov` model with an empty
  `aov` slot (in anticipation for `{afex}` v.1.0.0).

* Fixed issue in `model_info()` for *stanreg* object with non-standard
  model-family specification.

# insight 0.14.0

## General

* Better support for accessing auxiliary parameters (via `get_sigma()` and
  `get_auxiliary()`, as well as `get_parameters(component = "all")`) for
  `brmsfit` models.

## New functions

* `get_modelmatrix()` as a robust alternative to `model.matrix()` for different
  model classes.

* `format_message()` to format warnings and messages by adjusting the maximum
  line_length, possibly to the width of the console window.

* `format_string()` to shorten a string to a maximum length.

* `check_if_installed()` to see if the needed package is installed.

## New supported model classes

* Support for `mvord` (*mvord*), `SemiParBIV` (*GJRM*), `selection`
  (*sampleSelection*)

## Changes to functions

* `find_formula()` now warns when data name is present in formula, since this
  can result in unexpected behaviour in other package functions.

* `model_info()` returns `is_bernoulli = TRUE` for Bernoulli models.

* Add `get_statistic()` for *lavaan* models.

* `get_df()` supports more models/objects.

* `get_sigma()` supports more models/objects.

* `get_sigma()` and `get_deviance()` for `lrm` models (package *rms*) now only
  return one value, sigma or deviance for the model with intercept and
  predictors.

* `get_deviance()` now works for `glmerMod`, `MixMod` and `glmmTMB` models.

* The behaviour and documentation of the `effects` and `component` arguments, in
  particular for `brmsfit` models, were revised to be more consistent.

* `export_table()` now correctly prints the footer if the input was a list of
  data frames.

## Bug fixes

* Fixed issue (warning) in `get_loglikelihood()` for binomial models with
  non-numeric response variables.

* `find_statistic()` correctly distinguishes t- and z-statistic for *emmGrid*
  objects.

* Fixed issue in `model_info()` for `BGGM` and `mgcv::gam()`.

* Fixed issue in `find_formula()` for `gamlss` models with `random()` function
  in formula.

* Fixed issue with `find_parameters()` for *brmsfit* models when auxiliary
  parameters are directly modelled.

* Fixed issue with `get_parameters()` and `find_parameters()` for multi-group
  *blavaan* models.

* Fixed issue in `ellipsis_info()` when detecting nested models with
  poly-terms.

* Fixed issue in `find_response()` for *brmsfit* models that used the
  `resp_thres()` function in the model formula.

* Fixed issue in `get_predicted_ci()` for models with rank-deficient model
  matrix.

* Argument `zap_small` in `format_value()` did not work properly over vectorized
  vectors.

# insight 0.13.2

## General

* `get_predicted()` has be revamped with a new API and a stable output form (a
  vector). In the course of this revision, a new function `get_predicted_ci()`
  to calculate uncertainty intervals for model predictions.

* Improved support for `orm` (*rms*).

## New supported model classes

* Support for `svy_vglm` (*svyVGAM*), `mjoint` (*joineRML*), `mhurdle`
  (*mhurdle*), `sarlm` (*spatialreg*), `model_fit` (*tidymodels*)

## New functions

* `is_gam_model()` as a small helper to check if a model is a generalized
  additive model with smooth terms.

## Changes to functions

* Added `iterations` argument to `get_predicted()` to control the number of
  draws returned for Bayesian models.

* `model_info()` now returns `$is_gam` if model is generalized additive model
  with smooth terms.

* `format_table()` and `export_table()` now check for valid input (e.g.,
  non-empty data frame) and give an informative message.

* Improved support for `MixMod` (*GLMMadaptive*) in `get_variance()`.

* Improved `print_parameters()`, to allow more flexibility and better cope with
  different output formats.

* `get_parameters()`, `find_parameters()` and `clean_parameters()` for *emmGrid*
  and *emm_list* objects were revised and now better match the actual parameter
  names (also for contrasts).

## Bug fixes

* Fixed issue in `get_variance()` for models without intercept.

* Fixed labelling issue in `get_parameters()` and `clean_parameters()` for
  `blavaan` models.

* `clean_parameters()` for *MCMCglmm* objects did not include random
  parameters.

* Fixed minor issue with unintended sub-titles for `print_html()`.

* Fixed issue in `get_prior()` for `rstanarm::R2()` priors.

# insight 0.13.1

## General

* Improved handling for GAMs.

## New supported model classes

* Support for `elm`, `eglm` (*eflm*)

## Changes to functions

* `get_residuals(..., weighted = TRUE)` doesn't throw warnings if weights are 1
  (no weights specified).

* `n_parameters()` gains a `only_estimable` argument, to remove non-estimable
  parameters from counting the number of parameters for models with
  rank-deficient model matrix.

* `format_ci()` also gains a `zap_small` argument.

## Bug fixed

* Fix or disable failing tests on Mac OS.

* Fixed issues in `get_variance()` with non-correlated random-slope-intercepts
  for *lme4* models.

# insight 0.13.0

## General

* Roll-back R dependency to R >= 3.4.

## New supported model classes

* Support for `crr` (*cmprsk*), `ergm` (*ergm*), `btergm` (*btergm*), `Rchoice`
  (*Rchoice*), `garch` (*tseries*)

## Changes to functions

* Slightly improved handling of different CI-columns in `format_table()`.

* `model_info()` now returns `$is_leventest` if model is an object returned by
  `car::leveneTest()`.

* `get_parameters()` supports `htest` objects.

## Bug fixes

* `get_varcov()` did not properly remove `NA` from rank-deficient models.

* Fixed issue/warning in `get_data()` for some *htest* objects, where the
  environment was not properly evaluated.

* Fixed issue in `format_table()` with p-value formatting, when input data frame
  contained a column named `"p"`, which was not numeric.

* (Hopefully) fixed issue with failing CRAN checks.

# insight 0.12.0

## Breaking changes

* `format_table()` is an alias for `parameters_table()`, and is no longer
  referring to `export_table()`.

## New supported model classes

* Support for `coxr` (*coxrobust*), `coeftest` (*lmtest*), `ivFixed`
  (*ivFixed*), `ivprobit` (*ivprobit*), `riskRegression` (*riskRegression*).
  `summary.lm`, `lmodel2` (*lmodel2*), improved support for `bamlss`
  (*bamlss*).

## New functions

* Added `get_deviance()` function that returns the model deviance as a robust
  alternative to `stats::deviance()`.

* Added `model_name()` function that returns the model's "name".

* Added `format()` method for `find_formula()` output to flatten it.

* Added `null_as_ones = TRUE` argument to `get_weights()` to return vector of 1s
  instead of `NULL`.

* Added `get_intercept()` as a helper function to easily retrieve the value at
  the intercept.

* Added `get_df()` as a robust alternative to `stats::df.residuals()`.

* Added `get_predicted()` as a robust alternative to `stats::fitted()`.

* Added `get_loglikelihood()` (and its alias `loglikelihood()`) function as a
  robust alternative to `stats::logLik()`.

* Added `get_residuals()` as a robust alternative extract model residuals.

* Added `ellipsis_info()` to specify the nature of ellipsis (`...`) inputs.

* Added `is_nested_models()` to check if multiple regression models are nested
  (decreasing or increasing).

* Added generic `print_html()`, to allow other packages to create tables in HTML
  format (via `export_table()`) when not printing the output to console.

* Added `is_mixed_model()`, to safely check if a model is a mixed effects model.
  This function also works for multivariate response models.

* `n_parameters()` was moved from *parameters* to *insight*.

## Changes to functions

* `find_formula()`, `find_predictor()`, `find_random()` and related functions
  now also return names of random effects from generalized additive mixed models
  (`gamm`, `gamm4`, `stan_gamm4`).

* Added support for more BFBayesFactor objects.

* `model_info()` now returns `$is_xtab` for `chisq.test()` and
  `BayesFactor::contingencyTableBF()`. Furthermore, the `$family` element for
  those objects is set to `"categorical"`.

* `n_obs()` now handles number of observations from models with binomial family
  correctly when these have matrix-columns as response variable.

## Bug fixes

* Fixed issue in `find_statistic()` for *fixest* models, which did not return
  the correct value `"t-statistic"` for `feols()`.

* Fixes inconsistencies in `get_priors()` for (linear) `BFBayesFactor` models.

# insight 0.11.1

## General

* Warnings that formerly were printed using `print_color()` now use `warning()`,
  to better suppress warning messages if required.

## New functions

* `find_smooth()`, to return in particular smooth terms used in a model.

## Changes to functions

* `get_variance()` and `get_variance_random()` gain a `tolerance`-argument, to
  set the tolerance level for singularity checks when computing random effect
  variances.

* `parameters_table()` formats more objects from the *easystats* packages, like
  ROPE-range or `p_rope()`.

* `find_statistic()` now supports models of class *scam*.

* `get_data()` now also supports `htest`-object, where possible.

## Bug fixes

* Fix CRAN check issues.

* `find_formula()` for `stan_gamm4()` now correctly includes random effects.

# insight 0.11.0

## Breaking changes

* `model_info()` now also detects models from `oneway.test()`, `binom.test()`
  `chisq.test()`, `mcnemar.test()` and `prop.test()`. Furthermore,
  `model_info()` better deals with objects from `BFBayesFactor`, and censored
  regression models no longer return `TRUE` for `$is_linear`.

* `format_table()` is going to be renamed in a future update. Please use its
  alias `export_table()`.

## New supported model classes

* Support for `scam` (*scam*), `meta_random` and `meta_fixed` (*metaBMA*), `Glm`
  (*rms*), `ridgelm` (*MASS*), `mediate` (*mediation*). Partial support for
  `mcmc.list` (e.g. *bayesGARCH*)

## New function

* `parameters_table()`, which was moved from package *parameters* to *insight*.
  Note that this function is going to be renamed into `format_table()` in a
  future update.

* `find_offset()`, to find the name of offset-terms.

* Added generics for `display()` and `print_md()`, to allow other packages to
  create tables in other formats when not printing the output to console.

## Changes to functions

* `standardize_names()` tries to be as loyal to the *broom*-naming conventions
  as possible.

* The function of the `brackets`-argument in `format_ci()` was changed. It is
  now also possible to provide a length-two character vector, to define own
  brackets that encompass the CI-values.

* Related to the change in `format_ci()`, the function of the
  `brackets`-argument in `parameters_table()` was changed accordingly.
  Furthermore, `parameters_table()` gains a `preserve_attributes`-argument, to
  preserve any attributes from the input data frame.

* `export_table()` gains several new arguments that allows to create tables in
  markdown-format.

* `print_parameters()` gains a `keep_parameter_column`-argument, to keep
  (default) both the `"Cleaned_Parameter"` and `"Parameter"` columns, or - if
  `FALSE` - use `"Cleaned_Parameter"` as new `"Parameter"` column.

## Bug fixes

### `get_data()`

* Fixed issue in `get_data()` for `MixMod` objects, which were caused due to
  internal changes in *GLMMadaptive*.

* `get_data()` for zero-inflated models from *pscl* did not include the
  offset-term in cases where the offset was defined as argument, not inside the
  model formula.

* Fixed issue in `get_data()` for `coxph` models with survival-objects with
  `event`-argument as response.

* Fixed edge case in `get_data()` for column name of response values that were
  log-transformed using `log(x+1)`.

### Other bug fixes

* Fixed issue with `survreg` models that included `strata()` in their formula.

* Fixed warning in CRAN checks for forthcoming R-devel.

# insight 0.10.0

## New function

* `get_sigma()` to return the residual standard deviation.

* `standardize_names()`, which was moved from package *parameters* to
  *insight*.

## New supported model classes

* Support for `maov` (*stats*), `HLfit` (*spaMM*), preliminary support for
  `margins` (*margins*), `merModList` (*merTools*).

## General

* Better support for (weighted) multivariate response models of class `mlm` for
  functions like `get_varcov()` or `clean_parameters()`.

* Make `find_formula()` work with t-tests from *BayesFactor*.

* Improved handling for *mira* objects.

## Changes to functions

* `format_bf()` gains a `na_reference` argument, to set the "reference" for
  Bayes factor values that are `NA`, and an `exact` argument for returning
  scientific formatted extreme values.

* `format_value()` gains a `zap_small` argument, to prevent scientific printing
  of numbers if these have more decimal places than indicated by `digits`.

* `get_weights()` now also returns `NULL` when all weights were 1.

* `get_parameters()` for *BFBayesFactor* objects gets a `verbose` argument.

* `get_parameters()` for *emmGrid* and *emm_list* objects gets a `summary`
  argument, to either return the full posterior samples or the summarized
  centrality indices for Bayesian models.

* `find_formula()` for `MuMIn::model.avg()` now tries to retrieve the random
  effects part of a formula, when present.

* `get_weights()` gains a `na_rm` argument to remove possible missing values.

## Bug fixes

* Fix issues with one-sample Bayesian t-tests (
  https://github.com/easystats/parameters/issues/297 ).

* Fix issue in `format_value()` that printed `"100%"` as `"1e+02%"`.

* Removed unnecessary white-spaces in `format_ci()` when upper or lower interval
  was larger than 1e+5.

* `has_intercept()` did not work correctly when intercept was removed from
  formula using `-1`.

* `find_terms()` now shows removal of intercept formula using `-1` as term
  `"-1"`.

* Fix issues with `get_statistic()` for *vgam* models.

# insight 0.9.6

## Changes to functions

* `get_data()` now works for models from `afex_aov()`.

* `get_parameters()` returns a more informative message for `BFBayesFactor`
  objects when not the first model is indexed.

* `clean_names()` now also removes `exp()`-pattern.

* `clean_names()` for character-objects now works with "interaction patterns"
  (like `clean_names("scale(a):scale(b)")`).

* `format_bf()` gains a `protect_ratio` argument, to print numbers smaller than
  1 as ratios.

## Bug fixes

* Fix issues in CRAN checks.

* `get_priors()` now works for more complex `BFBayesFactor` objects that have
  multiple custom priors.

# insight 0.9.5

## Breaking changes

* `get_data()` did not always "back-transform" log-transformed or scaled
  variables to return the original values. Now this bug has been fixed, and
  `get_data()` should return all variables on the original scale (as if these
  variables were not transformed), as stated in the docs.

## Bug fixes

* `get_data()` now returns the correct original data for "empty" polynomials
  (i.e. `poly(x, 1)`).

* Fix CRAN check issues due to latest _estimatr_ update.

# insight 0.9.1

## New supported model classes

* Support for `mipo` (*mice*), `lqmm` and `lqm` (*lqmm*). Preliminary support
  for `semLME` (*smicd*), `mle` (*stats4*) and `mle2` (*bbmle*).

## Changes to functions

* `model_info()` returns `$is_meta = TRUE` for *brms*-meta-analysis models.

* Make `find_statistic()` work with `mgcv::bam()`.

* `get_variance()` now also support `truncated_nbinom2()` family from
  *glmmTMB*.

## Bug fixes

* Fixed issue with correctly detecting sigma-parameters in `find_parameters()`
  for multiple-response `brmsfit`-models.

* Fixed issue with `find_formula()` for models from `stan_nlmer()`.

* Fixed issues with `find_terms()` when response variable included a namespace,
  like `survival::Surv()`.

* Fixed issues with `get_priors()` for _stanreg_ models, probably caused by the
  latest update to *rstanarm 2.21.2*.

* Fixed issues in `get_variance()` for *brmsfit* models.

* Fixed some issues around `crq` objects (package *quantreg*).

# insight 0.9.0

## New supported model classes

* `BGGM` (*BGGM*), `metaplus` (*metaplus*), `glht` (*multcomp*), `glmm`
  (*glmm*), improved support for `manova` (*stats*)

## New functions

* Value formatting functions `format_bf()`, `format_pd()`, `format_p()`,
  `format_rope()` and `format_number()` were moved from package *parameters* to
  *insight*.

## Changes to functions

* `get_variance()` now also returns the correlation among random slopes.

* `get_variance()` now also (partially) supports `brmsfit` models.

* `get_parameters()` for models that return (posterior or simulated) samples of
  model parameters gains a `summary`-argument, which - if `TRUE` - returns a
  point-estimate (mean of samples) instead of the full samples.

* `format_p()` returns `"> .999"` for p-values equal to or greater than 0.999.

## Bug fixes

* Fixed issue in `find_formula()` that did not properly work for models with
  random effects in formula (in *lme4* notation), when random effects were in
  between fixed effects parts.

* `get_variance()` did not return variance components for random effects for
  null-models with random slopes.

* Fixed issue with `get_variance()` for `lme`-models with categorical random
  slope.

* Fixed issue that occurred since R 4.0.0 in `find_weights()` when function call
  had no `weights`-argument.

* Fixed issue in `get_data()` for models with `cbind()`-response variables and
  matrix-like variables in the model frame (e.g. when using `poly()`).

* Fixed issues with `PROreg::BBmm()`, due to changes in latest package update.
